# Spam Protection
Minetest Mod against spam in chat

Licensed under WTFPL.

Forum : https://forum.minetest.net/viewtopic.php?f=9&t=21052
