# lava_ore_gen
mod for minetest

This mod makes the lava turn stone into ore over time.
