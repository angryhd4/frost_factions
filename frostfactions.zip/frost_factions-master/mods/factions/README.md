# factions
mod for minetest

Mod for handling in game factions and reputation.

# TODO LIST

Redo the parcel attack system(Can be turned on in settings).

Add command to show or hide all parcel position locations as markers.

Add money.

Player money tax.

faction territory titles.

faction territories (Like a faction within a faction)

faction color.

Color tags based on faction color(add support for entity tag mods).

More claim and unclaim commands.

faction access manage command.

Maybe expand on diplomacy.

Write the forum topic better.

Code clean up and optimization.

Add short worded commands.

Parcels should show up at a more accurate position just like in mc factions.

Add-on mod mc style tnt.

Add-on mod lag-free fire(if thats possible).