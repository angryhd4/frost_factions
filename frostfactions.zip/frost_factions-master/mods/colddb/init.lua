modpath = minetest.get_modpath("colddb")

dofile(string.format("%s/async.lua",modpath))
dofile(string.format("%s/colddb.lua",modpath))