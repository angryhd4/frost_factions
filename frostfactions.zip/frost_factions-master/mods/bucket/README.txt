Minetest Game mod: bucket
=========================
See license.txt for license information.

Authors of source code
----------------------
Kahrl <kahrl@gmx.net> (LGPL 2.1)
celeron55, Perttu Ahola <celeron55@gmail.com> (LGPL 2.1)
Various Minetest developers and contributors (LGPL 2.1)

Authors of media (textures)
---------------------------
ElementW (CC BY-SA 3.0)
