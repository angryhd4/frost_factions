ec_config = {}

ec_config.explosion_max = 11
ec_config.volatile_containers = true
ec_config.volatile_protected_containers = true
ec_config.explosive_traps = true
